export { SidebarEditor } from './sidebar-editor/index'
